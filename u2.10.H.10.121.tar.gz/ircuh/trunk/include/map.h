#if !defined(MAP_H)
#define MAP_H

/*=============================================================================
 * Proto types
 */

extern int m_map(aClient *cptr, aClient *sptr, int parc, char *parv[]);

#endif /* MAP_H */
