#if !defined(VERSION_H)
#define VERSION_H

extern const char *version;
extern const char *creation;
extern const char *infotext[];
extern const char *generation;

#endif /* VERSION_H */
