#if !defined(NETWORK_H)
#define NETWORK_H

/****************************************
 * Nombre de la red en NETWORK_NAME    *
 ****************************************/

#define NETWORK_NAME "IRC-Hispano"
#define SERVER_NAME "*.irc-hispano.org"
#define SERVER_INFO "Servidor de IRC-Hispano, Chat en castellano"

#endif
