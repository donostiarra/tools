#if !defined(RANDOM_H)
#define RANDOM_H

/*=============================================================================
 * Proto types
 */

extern unsigned int ircrandom(void);

#endif /* RANDOM_H */
