#if !defined(S_NUMERIC_H)
#define S_NUMERIC_H

/*=============================================================================
 * Proto types
 */

extern int do_numeric(int numeric, int nnn, aClient *cptr, aClient *sptr,
    int parc, char *parv[]);

#endif /* S_NUMERIC_H */
